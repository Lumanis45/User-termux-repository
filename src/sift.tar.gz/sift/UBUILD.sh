#!/bin/bash

# Package name: Sift
# Version: 1ad14a10ef06aa0a10175242ad7e46364cf007d8 commit on github
# Source: https://github.com/svent/sift

# Author of the port: Lumanis45
# Author email: humblex29@gmail.com
# Date: 13.03.26

pkg update && pkg install -y golang git build-essential binutils

mkdir -p "$1/$3/bin"

go build

cp sift "$1/$3/bin/sift" || exit 1
ln -sf "$1/$3/bin/sift" "$2/sift"

pkg autoclean && pkg clean
# Made with love, by Lumanis45!
