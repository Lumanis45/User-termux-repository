#!/bin/bash

# Package name: utp-tool 
# Version: 0.1
# Source: https://github.com/Lumanis45/User-termux-repository/raw/refs/heads/main/src/utp-pack.tar.gz

# Author of the port: Lumanis45
# Author email: humblex29@gmail.com
# Date: 03.03.26

mkdir -p "$1/$3"
chmod +x "$3"
cp "$3" "$1/$3"
ln -sf "$1/$3" "$2/$3"
chmod +x "$2/$3"

# Made with love, by Lumanis45!
