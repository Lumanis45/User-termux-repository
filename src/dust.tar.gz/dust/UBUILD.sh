#!/bin/bash

# Package name: Dust
# Version: 93fe658574b1677052fba8b042283174b0fdef49 commit on github
# Source: https://github.com/bootandy/dust

# Author of the port: Lumanis45
# Author email: humblex29@gmail.com
# Date: 05.03.26

pkg update && pkg install -y rust binutils

mkdir -p "$1/$3/bin"

cargo build --release --locked

cp target/release/dust "$1/$3/bin/dust"

ln -sf "$1/$3/bin/dust" "$2/dust"

pkg autoclean && pkg clean
# Made with love, by Lumanis45!
