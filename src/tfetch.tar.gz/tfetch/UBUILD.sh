#!/bin/bash

# Package name: Tfetch
# Version: 1b19e573e1a14de9c64ab794137c001f3d805acc commit on github
# Source: https://github.com/haithamaouati/tfetch

# Author of the port: Lumanis45
# Author email: humblex29@gmail.com
# Date: 05.03.26

pkg update

mkdir -p "$1/$3/bin"
cp tfetch.sh "$1/$3/bin/tfetch"
chmod +x "$1/$3/bin/tfetch"

ln -sf "$1/$3/bin/tfetch" "$2/tfetch"

pkg autoclean && pkg clean
# Made with love, by Lumanis45!
